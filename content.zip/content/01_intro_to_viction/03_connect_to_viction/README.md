# Connecting to Viction Networks

To interact with the Viction blockchain, you can connect to either the **Mainnet** or the **Testnet**. Each network has distinct specifications, but they share the same structure, allowing for a smooth transition between development and production environments. Here's a combined overview:

| **Specification**       | **Viction Mainnet**                                | **Viction Testnet**                                    |
|-------------------------|----------------------------------------------------|--------------------------------------------------------|
| **Chain ID**             | 88 or 0x58                                         | 89                                                     |
| **RPC Endpoint**         | [https://rpc.viction.xyz](https://rpc.viction.xyz) | [https://rpc-testnet.viction.xyz](https://rpc-testnet.viction.xyz) |
| **WebSocket Endpoint**   | [wss://ws.viction.xyz](wss://ws.viction.xyz)       | [wss://ws-testnet.viction.xyz](wss://ws-testnet.viction.xyz)       |
| **HD Derivation Path**   | `m/44'/60'/0'/0/`                                  | `m/44'/60'/0'/0/`                                      |
| **Consensus**            | POSV (Proof of Stake Voting)                       | POSV (Proof of Stake Voting)                           |
| **Block Finality**       | >75%                                               | >75%                                                   |
| **Consensus Nodes**      | Up to 150 (Masternodes)                            | Up to 150 (Masternodes)                                |
| **Genesis Block Date**   | December 14th, 2018                                | -                                                      |
| **Transaction Fee**      | Gas price 0.25 Gwei                                | -                                                      |
| **Solidity Compiler**    | Versions <= 0.8.17                                 | Versions <= 0.8.17                                     |

## Further Information

For more details on network configurations and how to connect, visit the official Viction documentation: [Viction Network Information](https://docs.viction.xyz/general/network-information).
